- As .Net Is Now 64 Bit Only ( Both VB.Net And C#.Net ), For Their Clients All 3 Entities,
  i.e. COM Automation Server Dll, Proxy/Stub Dll And Client Exe Must Be 64 Bit.
